package pairsGame

class EnrolPlayer implements Serializable {
	def name = ""
	def toPlayerChannelLocation = null
}
