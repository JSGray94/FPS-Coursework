package pairsGame

class GetValidPoint  implements Serializable {
	def side
	def gap
	def pairsMap
}
