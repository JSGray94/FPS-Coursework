package pairsGame

class MousePoint implements Serializable {
	def point = []
}
