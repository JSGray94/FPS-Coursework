package pairsGame

class SquareCoords implements Serializable {
	def location = []
}
