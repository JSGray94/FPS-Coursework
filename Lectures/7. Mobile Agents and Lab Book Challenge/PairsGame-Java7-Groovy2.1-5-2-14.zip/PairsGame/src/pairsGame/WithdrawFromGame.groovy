package pairsGame

class WithdrawFromGame implements Serializable {
	def id
}
