package pairsGame

class GetGameDetails implements Serializable {
	int id
}
